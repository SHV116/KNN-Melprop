"""Assemble the single-file HTML report. No JavaScript: the option switcher and the image
viewer work with plain HTML and CSS."""

from __future__ import annotations

import base64
import datetime as dt
import html
import math
from pathlib import Path
from string import Template

import pandas as pd

from .geometry import Diffuser
from .review import BaselineMetrics

HERE = Path(__file__).parent


def _img(path: Path) -> str:
    return "data:image/webp;base64," + base64.b64encode(path.read_bytes()).decode()


def _f(v: float, d: int = 2) -> str:
    """Number without trailing zeros."""
    return f"{v:.{d}f}".rstrip("0").rstrip(".")


def _kpi(name: str, value: str, frac: float, ticks: list[tuple[float, str]], band: tuple[float, float, str] | None = None) -> str:
    parts = [f'<div class="kpi"><div class="kpi-head"><span class="kpi-name">{name}</span><span class="kpi-val">{value}</span></div>',
             '<div class="bar" style="position:relative;height:16px;margin:4px 0 2px">',
             '<span style="position:absolute;left:0;right:0;top:4px;height:8px;border-radius:4px;background:var(--band)"></span>']
    if band:
        parts.append(f'<span style="position:absolute;left:{band[0]*100:.1f}%;width:{(band[1]-band[0])*100:.1f}%;top:1px;height:14px;background:#C9D3DC"></span>')
    parts.append(f'<span style="position:absolute;left:0;width:{min(frac,1)*100:.1f}%;top:4px;height:8px;border-radius:4px;background:var(--problem)"></span>')
    for t, _ in ticks:
        parts.append(f'<span style="position:absolute;left:calc({t*100:.1f}% - 1px);top:0;width:2px;height:16px;background:var(--ink)"></span>')
    parts.append("</div>")
    notes = []
    if band:
        notes.append(f'<span><i style="width:14px;height:10px;background:#C9D3DC;display:inline-block;margin-right:5px"></i>{band[2]}</span>')
    for _, label in ticks:
        notes.append(f'<span><i style="width:2px;height:12px;background:var(--ink);display:inline-block;margin-right:5px;vertical-align:-1px"></i>{label}</span>')
    parts.append(f'<div style="display:flex;gap:14px;flex-wrap:wrap;color:var(--ink3);font-size:13px">{"".join(notes)}</div></div>')
    return "".join(parts)


def _status_icon(status: str) -> str:
    if status == "done":
        return '<svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true"><circle cx="9" cy="9" r="7.5" fill="var(--ok)"/><path d="M5 9.3 L7.8 12 L13 6.4" stroke="#fff" stroke-width="2" fill="none"/></svg>'
    if status == "check":
        return '<svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true"><path d="M9 1.5 L17 16 L1 16 Z" fill="var(--check)"/><rect x="8" y="6" width="2" height="5.5" fill="#fff"/><rect x="8" y="13" width="2" height="2" fill="#fff"/></svg>'
    return '<svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true"><circle cx="9" cy="9" r="7" fill="none" stroke="var(--todo)" stroke-width="2"/></svg>'


def angle_text(geo: Diffuser) -> str:
    if geo.vanes:
        return f"{_f(geo.widest_channel_angle, 1)}° per channel ({_f(geo.wall_angle_wide, 1)}° overall)"
    return f"{_f(geo.wall_angle_wide, 1)}°, one channel"


def build_html(fluent: dict, geo: Diffuser, base: BaselineMetrics, options: pd.DataFrame, geometries: dict[str, Diffuser],
               checks: list[dict], figures: dict[str, str], image_dir: Path) -> str:
    op = fluent["operating_point"]
    m_g = base.mass_flow * 1000
    img = {p.stem: _img(p) for p in image_dir.glob("*.webp")}
    best = options.loc["all"]

    kpis = "".join([
        _kpi("Pressure recovery Cp", _f(base.cp, 2), base.cp, [(base.cp_ideal, f"ideal {_f(base.cp_ideal, 2)}")], (0.6, 0.7, "good straight diffuser 0.6–0.7")),
        _kpi("Total-pressure loss, share of bore dynamic pressure", f"{base.loss_coefficient*100:.0f} %", base.loss_coefficient, [(0.2, "good ≈ 20 %")]),
        _kpi("Exit speed, area mean", f"{_f(base.exit_mean_velocity, 1)} m/s", base.exit_mean_velocity / 40, [(base.exit_uniform_velocity / 40, f"uniform {_f(base.exit_uniform_velocity, 1)} m/s")]),
        _kpi("Supply pressure needed, above the stand", f"+{_f(base.supply_gauge/1000, 1)} kPa", base.supply_gauge / 30000, [(best.supply_kPa / 30, f"all fixes ≈ {best.supply_kPa:.0f} kPa (estimate)")]),
        _kpi("Bore flow, share of its choking limit", f"{base.choke_share*100:.0f} %", base.choke_share, [(1.0, "chokes")]),
    ])

    # design options: radio buttons, labels and one panel per option
    keys = list(options.index)
    radios = "".join(f'<input class="opt-input" type="radio" name="opt" id="opt-{k}"{" checked" if k == "today" else ""}>' for k in keys)
    labels = "".join(f'<label for="opt-{k}">{html.escape(options.loc[k, "label"])}</label>' for k in keys)
    css_rules = []
    panels = []
    for k in keys:
        r, g = options.loc[k], geometries[k]
        sel_colour = "var(--problem)" if k == "today" else "var(--fix)"
        css_rules.append(f'#opt-{k}:checked ~ .opt-list label[for="opt-{k}"] {{ background: {sel_colour}; border-color: {sel_colour}; color: #fff; }}')
        css_rules.append(f'#opt-{k}:focus-visible ~ .opt-list label[for="opt-{k}"] {{ outline: 2px solid var(--fix); outline-offset: 2px; }}')
        css_rules.append(f'#opt-{k}:checked ~ .opt-panels #panel-{k} {{ display: block; }}')
        if k == "today":
            cp_txt = f"{_f(r.cp, 2)} (CFD)"
            sup_txt = f"+{_f(r.supply_kPa, 1)} kPa (CFD)"
        elif pd.isna(r.cp):
            cp_txt = sup_txt = "Not estimated yet"
        else:
            cp_txt = f"≈ {_f(r.cp, 2)} ({_f(r.cp_low, 2)}–{_f(r.cp_high, 2)})"
            sup_txt = f"≈ +{r.supply_kPa:.0f} kPa ({r.supply_low_kPa:.0f}–{r.supply_high_kPa:.0f})"
        step_txt = f"≈ {r.step_loss_kPa:.0f} kPa" if g.entry == "step" and not pd.isna(r.step_loss_kPa) else ("none" if g.entry != "step" else "step stays")
        outside = "Same as today" if abs(r.length_change_mm) < 0.05 else f"{r.length_change_mm:+.0f} mm longer"
        rows = [("Walls open at", angle_text(g)), ("Entry-step loss", step_txt), ("Recovery Cp", cp_txt),
                ("Supply pressure for " + _f(m_g, 2) + " g/s", sup_txt), ("Exit flow", r.exit_flow), ("Outside of the part", outside)]
        table = "".join(f'<tr><th scope="row">{a}</th><td>{html.escape(b)}</td></tr>' for a, b in rows)
        catch = f'<p><strong>The catch.</strong> {html.escape(r.catch)}</p>' if r.catch else ""
        legend = ("Today's part as built. Flow pattern traced from the CFD." if k == "today"
                  else "Dashed orange: today's part. Not simulated yet.")
        panels.append(
            f'<div class="opt-panel" id="panel-{k}"><div class="drawing">{figures["geo_" + k]}</div>'
            f'<p class="fig-cap">Top view, to scale. {legend}</p>'
            f'<div class="detail-grid"><div><h3>{html.escape(r.label)}</h3><span class="tag">{html.escape(r.kind)}</span>'
            f'<p style="margin-top:10px"><strong>What changes.</strong> {html.escape(r.what_changes)}</p>'
            f'<p><strong>Result.</strong> {html.escape(r.result)}</p>{catch}</div>'
            f'<table class="kv">{table}</table></div></div>')

    # options summary table
    head = "<tr><th>Option</th><th>Widest angle</th><th>Entry-step loss</th><th>Cp</th><th>Supply pressure</th><th>Length change</th></tr>"
    body = []
    for k in keys:
        r = options.loc[k]
        cp = "–" if pd.isna(r.cp) else (_f(r.cp, 2) if k == "today" else f"{_f(r.cp, 2)} ({_f(r.cp_low, 2)}–{_f(r.cp_high, 2)})")
        sup = "–" if pd.isna(r.supply_kPa) else (f"{r.supply_kPa:.1f} kPa" if k == "today" else f"{r.supply_kPa:.1f} kPa ({r.supply_low_kPa:.0f}–{r.supply_high_kPa:.0f})")
        step = f"{r.step_loss_kPa:.1f} kPa" if r.step_loss_kPa > 0 and not pd.isna(r.step_loss_kPa) else ("–" if pd.isna(r.step_loss_kPa) else "none")
        body.append(f"<tr><td>{html.escape(r.label)}</td><td>{_f(r.widest_channel_deg, 1)}°</td><td>{step}</td><td>{cp}</td><td>{sup}</td><td>{r.length_change_mm:+.0f} mm</td></tr>")
    options_table = f'<div class="table-scroll"><table class="data"><thead>{head}</thead><tbody>{"".join(body)}</tbody></table></div>'

    # checks (the mass balance is computed)
    check_items = []
    for c in checks:
        detail = c["detail"]
        if c["check"] == "Mass balance":
            detail = f"In and out agree within {abs(base.mass_balance)*100:.2f} %."
        check_items.append(f'<li>{_status_icon(c["status"])}<div><span class="what">{html.escape(c["check"])}</span>'
                           f'<span class="why">{html.escape(detail)}</span></div><span class="state">{html.escape(c["state"])}</span></li>')
    model_err = base.model_supply_gauge / base.supply_gauge - 1
    check_items.append(f'<li>{_status_icon("done")}<div><span class="what">1D model against the CFD</span>'
                       f'<span class="why">At the CFD\'s Cp the 1D model needs {_f(base.model_supply_gauge/1000, 1)} kPa of supply pressure; '
                       f'Fluent needed {_f(base.supply_gauge/1000, 1)} kPa ({model_err*100:+.1f} %).</span></div><span class="state">Done</span></li>')

    calc_rows = [
        ("Inlet total pressure", f"{fluent['inlet']['total_pressure_gauge_Pa']:,.0f} Pa gauge", "Fluent"),
        ("Inlet Mach number", _f(fluent["inlet"]["mach"], 3), "Fluent"),
        ("Bore static pressure, p₁", f"{base.bore_static_gauge/1000:.2f} kPa gauge", "p₀₁ (1 + 0.2 M²)^−3.5"),
        ("Bore dynamic pressure, q₁", f"{base.bore_dynamic_pressure/1000:.2f} kPa", "p₀₁ − p₁"),
        ("Pressure recovery Cp", f"{base.cp:.3f}", "(p₂ − p₁) / q₁, with p₂ = outlet static pressure"),
        ("Ideal Cp", f"{base.cp_ideal:.3f}", "1 − 1/AR², AR from the bore"),
        ("Loss coefficient K", f"{base.loss_coefficient:.3f}", "(p₀₁ − p₀₂) / q₁"),
        ("Entry-step loss", f"{base.step_loss_coefficient:.3f} of q₁ ({base.step_loss/1000:.1f} kPa)", "Borda–Carnot, (1 − A_bore/A_square)²"),
        ("Bore Reynolds number", f"{base.bore_reynolds:,.0f}", "ρVD/μ, Sutherland viscosity"),
        ("Mass-flow cross-check", f"{base.mass_flow_check*100:+.2f} %", "ρ₁V₁A_bore against the set mass flow"),
        ("Uniform exit speed", f"{base.exit_uniform_velocity:.1f} m/s", "ṁ / (ρ₂ A_exit)"),
        ("Share of the choking flow", f"{base.choke_share*100:.1f} %", "ṁ / ṁ at Mach 1 for the bore"),
    ]
    calc_table = "".join(f"<tr><td>{a}</td><td>{c}</td><td>{b}</td></tr>" for a, b, c in calc_rows)

    lightboxes = []
    shots = [
        ("velocity_vectors_stalled_wall", "Zoom on the stalled wall", "Arrows along the wall point back towards the inlet: reversed flow, swirling up into the jet."),
        ("mach_side_cut", "Side cut, Mach number", "Cut through the 9.4 mm height: the jet stays centred, so the 2° thin-plane walls are fine. The plates show as thin slits."),
        ("mach_3d", "Whole part, Mach number", "The fast flow is confined to the bore, where Mach reaches about 0.79; the taper and the plates see low speeds."),
        ("velocity_vectors", "Mid-plane, full view", "Velocity vectors in the wide plane without the markers."),
    ]
    gallery = []
    for name, title, cap in shots:
        gallery.append(f'<figure class="shot"><a class="thumb" href="#zoom-{name}"><img src="{img[name]}" width="1600" height="900" alt="{html.escape(title)}"></a>'
                       f'<figcaption><strong>{title}</strong><span>{cap}</span></figcaption></figure>')
        lightboxes.append(f'<div class="lightbox" id="zoom-{name}"><figure><img src="{img[name]}" alt="{html.escape(title)}">'
                          f'<figcaption><span>{cap}</span><a class="close" href="#evidence">Close</a></figcaption></figure></div>')
    lightboxes.append(f'<div class="lightbox" id="zoom-residuals"><figure><img src="{img["residuals"]}" alt="Scaled residuals">'
                      f'<figcaption><span>Scaled residuals over about 2,700 iterations.</span><a class="close" href="#trust">Close</a></figcaption></figure></div>')
    lightboxes.append(f'<div class="lightbox" id="zoom-hero"><figure><img src="{img["velocity_vectors"]}" alt="Mid-plane velocity vectors">'
                      f'<figcaption><span>Mid-plane velocity vectors in the wide plane.</span><a class="close" href="#top">Close</a></figcaption></figure></div>')

    template = Template((HERE / "template.html").read_text(encoding="utf-8"))
    return template.substitute(
        css=(HERE / "report.css").read_text(encoding="utf-8") + "\n" + "\n".join(css_rules),
        rpm=f"{op['engine_speed_rpm']:,}",
        mass_flow=_f(m_g, 2),
        cp_pct=f"{base.cp*100:.0f}",
        kpis=kpis,
        hero_img=img["velocity_vectors_hero"],
        wall_angle=_f(geo.wall_angle_wide, 1),
        thin_angle=_f(geo.wall_angle_thin, 1),
        lw=_f(geo.length_to_width, 1),
        step_pct=f"{base.step_loss_coefficient*100:.0f}",
        step_kpa=f"{base.step_loss/1000:.0f}",
        cone_angle=_f(geo.equivalent_cone_angle, 1),
        options_chart=figures["options"],
        options_table=options_table,
        radios=radios, labels=labels, panels="".join(panels),
        gallery="".join(gallery),
        checks="".join(check_items),
        residuals_img=img["residuals"],
        calc_table=calc_table,
        ar_start=_f(geo.area_ratio_start, 2), ar_bore=_f(geo.area_ratio_bore, 2),
        bore_mach=_f(base.bore_mach, 2), reynolds=f"{base.bore_reynolds:,.0f}", choke_pct=f"{base.choke_share*100:.0f}",
        lightboxes="".join(lightboxes),
        built=dt.date.today().strftime("%d %B %Y"),
    )
