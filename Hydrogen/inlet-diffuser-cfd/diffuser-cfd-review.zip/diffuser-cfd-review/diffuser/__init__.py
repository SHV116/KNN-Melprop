"""CFD design review of the MELprop inlet diffuser: calculations, figures and the HTML report."""
