"""Turn the raw Fluent values and the design options into the numbers the report shows."""

from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

import pandas as pd

from . import gasdynamics as gd
from .geometry import Diffuser

MM2 = 1e-6  # mm^2 to m^2


def load_json(path: Path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


@dataclass(frozen=True)
class BaselineMetrics:
    """Results of the baseline Fluent run and the quantities derived from them."""

    mass_flow: float                 # kg/s, set at the inlet
    mass_balance: float              # (in - out) / in
    bore_mach: float
    bore_velocity: float             # m/s
    bore_static_gauge: float         # Pa
    bore_dynamic_pressure: float     # Pa, p01 - p1
    bore_reynolds: float
    mass_flow_check: float           # rho1 * V1 * A_bore / m_dot - 1
    supply_gauge: float              # Pa, inlet total pressure above the reference
    cp: float
    cp_ideal: float
    effectiveness: float
    loss_coefficient: float          # (p01 - p02) / q1
    step_loss_coefficient: float
    step_loss: float                 # Pa
    exit_mean_velocity: float        # m/s, area mean from Fluent
    exit_uniform_velocity: float     # m/s, if the same mass flow left evenly
    exit_skew: float                 # mean / uniform - 1
    choke_share: float               # m_dot / choked mass flow of the bore
    model_supply_gauge: float        # Pa, from the 1D model at the CFD's Cp

    def as_dict(self) -> dict:
        return asdict(self)


def analyse_baseline(fluent: dict, geo: Diffuser) -> BaselineMetrics:
    op, inlet, outlet = fluent["operating_point"], fluent["inlet"], fluent["outlet"]
    p_ref, t0 = op["reference_pressure_Pa"], op["total_temperature_K"]
    m_dot = inlet["mass_flow_kg_s"]
    a_bore, a_exit = geo.bore_area * MM2, geo.exit_area * MM2

    bore = gd.state_from_total_pressure(inlet["mach"], p_ref + inlet["total_pressure_gauge_Pa"], t0)
    q1 = bore.dynamic_pressure
    p_exit = p_ref + outlet["static_pressure_gauge_Pa"]
    p0_exit = p_ref + outlet["total_pressure_gauge_Pa"]

    cp = (p_exit - bore.static_pressure) / q1
    cp_ideal = 1.0 - 1.0 / geo.area_ratio_bore**2
    uniform_exit = gd.uniform_state_from_static_pressure(m_dot, a_exit, p_exit, t0)
    reynolds = bore.density * bore.velocity * geo.bore_diameter / 1000.0 / gd.sutherland_viscosity(bore.temperature)
    model = gd.bore_state_for_recovery(m_dot, a_bore, t0, p_exit, cp)

    return BaselineMetrics(
        mass_flow=m_dot,
        mass_balance=(m_dot + outlet["mass_flow_kg_s"]) / m_dot,
        bore_mach=bore.mach,
        bore_velocity=bore.velocity,
        bore_static_gauge=bore.static_pressure - p_ref,
        bore_dynamic_pressure=q1,
        bore_reynolds=reynolds,
        mass_flow_check=bore.density * bore.velocity * a_bore / m_dot - 1.0,
        supply_gauge=inlet["total_pressure_gauge_Pa"],
        cp=cp,
        cp_ideal=cp_ideal,
        effectiveness=cp / cp_ideal,
        loss_coefficient=(bore.total_pressure - p0_exit) / q1,
        step_loss_coefficient=geo.step_loss_coefficient,
        step_loss=geo.step_loss_coefficient * q1,
        exit_mean_velocity=outlet["velocity_area_mean_m_s"],
        exit_uniform_velocity=uniform_exit.velocity,
        exit_skew=outlet["velocity_area_mean_m_s"] / uniform_exit.velocity - 1.0,
        choke_share=m_dot / gd.choked_mass_flow(a_bore, bore.total_pressure, t0),
        model_supply_gauge=model.total_pressure - p_ref,
    )


def analyse_options(options_data: dict, fluent: dict, baseline: BaselineMetrics) -> tuple[pd.DataFrame, dict]:
    """One row per design option, with the geometry and the supply pressure each Cp needs."""
    op = fluent["operating_point"]
    p_ref, t0 = op["reference_pressure_Pa"], op["total_temperature_K"]
    m_dot = baseline.mass_flow
    base = options_data["baseline_geometry"]
    today = Diffuser.from_dict(base)

    def supply(geo: Diffuser, cp: float | None) -> float:
        if cp is None or (isinstance(cp, float) and math.isnan(cp)):
            return math.nan
        return gd.bore_state_for_recovery(m_dot, geo.bore_area * MM2, t0, p_ref, cp).total_pressure - p_ref

    rows, geometries = [], {}
    for opt in options_data["options"]:
        geo = Diffuser.from_dict(base, opt["changes"])
        geometries[opt["key"]] = geo
        is_today = opt["key"] == "today"
        cp = baseline.cp if is_today else opt["cp"]
        if is_today:
            q1, supply_pa = baseline.bore_dynamic_pressure, baseline.supply_gauge
        elif cp is not None:
            q1 = gd.bore_state_for_recovery(m_dot, geo.bore_area * MM2, t0, p_ref, cp).dynamic_pressure
            supply_pa = supply(geo, cp)
        else:
            q1, supply_pa = math.nan, math.nan
        rows.append({
            "key": opt["key"],
            "label": opt["label"],
            "kind": opt["kind"],
            "entry": geo.entry,
            "taper_length_mm": geo.taper_length,
            "length_change_mm": geo.total_length - today.total_length,
            "vanes": geo.vanes,
            "wall_angle_deg": geo.wall_angle_wide,
            "widest_channel_deg": geo.widest_channel_angle,
            "step_loss_kPa": geo.step_loss_coefficient * q1 / 1000.0 if geo.entry == "step" else 0.0,
            "cp": cp,
            "cp_low": opt["cp_low"],
            "cp_high": opt["cp_high"],
            "supply_kPa": supply_pa / 1000.0,
            "supply_low_kPa": supply(geo, opt["cp_high"]) / 1000.0,   # better recovery, less pressure
            "supply_high_kPa": supply(geo, opt["cp_low"]) / 1000.0,
            "exit_flow": opt["exit_flow"],
            "what_changes": opt["what_changes"],
            "result": opt["result"],
            "catch": opt["catch"],
        })
    df = pd.DataFrame(rows).set_index("key")
    return df, geometries
