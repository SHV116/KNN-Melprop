"""Matplotlib figures for the report, returned as inline SVG strings."""

from __future__ import annotations

import io
import math
import re

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.patches import Circle, FancyArrowPatch, Polygon, Rectangle  # noqa: E402

from .geometry import Diffuser  # noqa: E402

INK, INK2, INK3 = "#1E2329", "#4B535C", "#6E7681"
RULE, BAND = "#D8DCE0", "#E4E8EC"
PROBLEM, FIX, MARK = "#C2410C", "#1F5F99", "#8C959F"
PASSAGE, HATCH = "#F7F9FB", "#A9B1B9"
FONT_STACK = "'Saira Semi Condensed', 'Arial Narrow', Arial, sans-serif"

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 9,
    "svg.fonttype": "none",
    "axes.edgecolor": RULE,
    "axes.labelcolor": INK2,
    "xtick.color": INK3,
    "ytick.color": INK2,
    "hatch.linewidth": 0.5,
})


def to_svg(fig, salt: str) -> str:
    """Inline SVG with no fixed size, so it scales with its container."""
    plt.rcParams["svg.hashsalt"] = salt   # stable, unique ids per figure
    buf = io.StringIO()
    fig.savefig(buf, format="svg", bbox_inches="tight", pad_inches=0.04, transparent=True)
    plt.close(fig)
    svg = buf.getvalue()
    svg = svg[svg.index("<svg"):]
    svg = re.sub(r'(<svg[^>]*?) width="[^"]*" height="[^"]*"', r"\1", svg, count=1)
    svg = re.sub(r"font-family:[^;\"']*('[^']*')?[^;\"]*", f"font-family:{FONT_STACK}", svg)
    return svg


# ---------------------------------------------------------------- design options chart
def options_chart(df: pd.DataFrame) -> str:
    """Wall angle, Cp and supply pressure for every option, with the estimate ranges."""
    rows = list(df.index)[::-1]
    y = np.arange(len(rows))
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.9), sharey=True, gridspec_kw={"wspace": 0.12})
    panels = [
        ("Widest wall angle per channel (°)", "widest_channel_deg", None, None, (0, 20), (8, 10), None),
        ("Pressure recovery Cp, higher is better", "cp", "cp_low", "cp_high", (0, 1), (0.6, 0.7), df.loc["today", "cp"]),
        ("Supply pressure for 7.42 g/s (kPa), lower is better", "supply_kPa", "supply_low_kPa", "supply_high_kPa",
         (0, 30), None, df.loc["today", "supply_kPa"]),
    ]
    for ax, (title, col, lo, hi, xlim, band, ref) in zip(axes, panels):
        ax.set_xlim(*xlim)
        ax.set_title(title, loc="left", fontsize=9.5, color=INK2, pad=8)
        if band:
            ax.axvspan(*band, color=BAND, zorder=0, lw=0)
        if ref is not None:
            ax.axvline(ref, color=PROBLEM, lw=1, ls=(0, (3, 3)), zorder=1)
        ax.grid(axis="x", color=RULE, lw=0.6)
        ax.set_axisbelow(True)
        for side in ("top", "right", "left"):
            ax.spines[side].set_visible(False)
        ax.tick_params(axis="y", length=0)
        for yi, key in zip(y, rows):
            r = df.loc[key]
            colour = PROBLEM if key == "today" else FIX if key == "next" else MARK
            v = r[col]
            if pd.isna(v):
                ax.text(xlim[0] + 0.02 * (xlim[1] - xlim[0]), yi, "not estimated yet", va="center",
                        fontsize=8.5, color=INK3, style="italic")
                continue
            if lo and not pd.isna(r[lo]):
                ax.plot([r[lo], r[hi]], [yi, yi], color=colour, lw=2.2, solid_capstyle="round", zorder=2)
            ax.plot(v, yi, "o", ms=8, color=colour, mec="white", mew=1.6, zorder=3)
    axes[0].set_yticks(y, [df.loc[k, "label"] for k in rows], fontsize=9.5)
    for k, lab in zip(rows, axes[0].get_yticklabels()):
        lab.set_color(PROBLEM if k == "today" else FIX if k == "next" else INK)
    fig.text(0.125, -0.02, "Shaded: 8–10° guide for straight diffusers; good diffusers reach Cp 0.6–0.7. "
             "Dashed: today. Lines: estimate ranges.", fontsize=8.5, color=INK3)
    return to_svg(fig, "options")


# ---------------------------------------------------------------- geometry drawings
def _passage(geo: Diffuser) -> np.ndarray:
    x, h = geo.outline()
    return np.vstack([np.column_stack([x, h]), np.column_stack([x[::-1], -h[::-1]])])


def geometry_drawing(geo: Diffuser, today: Diffuser, angle_text: str, salt: str, show_cfd_flow: bool = False) -> str:
    """Top view of one design option to scale, with today's part as a dashed outline."""
    x_min, x_max, y_min, y_max = -16.0, 152.0, -21.0, 41.5
    fig, ax = plt.subplots(figsize=(11, 11 * (y_max - y_min) / (x_max - x_min)))
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(y_max, y_min)          # y down, like the drawing on paper
    ax.set_aspect("equal")
    ax.axis("off")

    wall = 2.6
    yb = geo.exit_width / 2 + wall
    xe, x_end = geo.taper_end, geo.total_length
    is_today = geo == today
    colour = PROBLEM if is_today else FIX

    # solid part (hatched section) and passage
    ax.add_patch(Rectangle((0, -yb), x_end, 2 * yb, facecolor="white", edgecolor=HATCH, hatch="////", lw=0, zorder=1))
    ax.add_patch(Polygon(_passage(geo), closed=True, facecolor=PASSAGE, edgecolor="none", zorder=2))
    if geo.plates:
        x0, x1 = xe + geo.plates_start, xe + geo.plates_end
        ax.add_patch(Rectangle((x0, -geo.exit_width / 2), x1 - x0, geo.exit_width, facecolor="#DCE1E6", lw=0, zorder=3))
        ax.text((x0 + x1) / 2, 0, f"{geo.plates} plates", rotation=90, ha="center", va="center", fontsize=8, color=INK2, zorder=4)
    if not is_today:
        p = _passage(today)
        ax.plot(np.append(p[:, 0], p[0, 0]), np.append(p[:, 1], p[0, 1]), color=PROBLEM, lw=0.9, ls=(0, (4, 3)), zorder=6)

    # what the CFD shows today: a jet along one wall, reversed flow along the other
    if show_cfd_flow:
        xr = np.linspace(9, xe - 2, 50)
        lower = geo.half_width(xr) - 0.4
        ax.add_patch(Polygon(np.vstack([np.column_stack([xr, lower]), np.column_stack([xr[::-1], 0.15 * geo.half_width(xr[::-1]) + 0.6])]),
                             closed=True, facecolor="none", edgecolor=PROBLEM, hatch="\\\\\\\\", lw=0, alpha=0.7, zorder=5))
        xj = np.linspace(8, xe + 9, 40)
        yj = -(geo.half_width(xj) - 2.2)
        ax.plot(np.r_[3, xj[:-1]], np.r_[-1.2, yj[:-1]], color=PROBLEM, lw=2.4, solid_capstyle="round", zorder=7)
        ax.add_patch(FancyArrowPatch((xj[-2], yj[-2]), (xj[-1], yj[-1]), arrowstyle="-|>", mutation_scale=16, color=PROBLEM, lw=2.4, zorder=7))
        xm = geo.taper_start + 0.62 * geo.taper_length
        ax.text(xm, -(geo.half_width(xm) - 5.4), "jet on one wall (CFD)", ha="center", fontsize=8.5, color=PROBLEM, zorder=8)
        cx = 0.55 * (9 + xe - 2)
        cy = 0.55 * float(geo.half_width(cx))
        ax.add_patch(FancyArrowPatch((cx + 9, cy + 2.2), (cx - 12, cy - 0.6), connectionstyle="arc3,rad=-0.25",
                                     arrowstyle="-|>", mutation_scale=12, color=PROBLEM, lw=1.4, zorder=7))
        ax.text(cx - 4, yb + 4.8, "reversed flow (CFD)", ha="center", fontsize=8.5, color=PROBLEM)

    for (x0, y0), (x1, y1) in geo.vane_lines():
        ax.plot([x0, x1], [y0, y1], color=FIX, lw=2.2, solid_capstyle="round", zorder=7)

    # outlines, centre line
    p = _passage(geo)
    ax.plot(np.append(p[:, 0], p[0, 0]), np.append(p[:, 1], p[0, 1]), color=INK, lw=1.3, zorder=8)
    ax.add_patch(Rectangle((0, -yb), x_end, 2 * yb, fill=False, edgecolor=INK, lw=1.3, zorder=8))
    ax.plot([-6, x_end + 4], [0, 0], color=INK, lw=0.5, ls=(0, (12, 2, 2, 2)), zorder=9)

    # labels and the taper-length dimension
    ax.text(geo.taper_start + 0.5 * geo.taper_length, -yb - 2.0, f"walls open at {angle_text}", ha="center",
            fontsize=10, fontweight="bold", color=colour)
    ax.text(-5, -0.7, "Ø6 bore", ha="right", va="bottom", fontsize=8.5, color=INK2)
    ax.text(-5, 0.7, "flow →", ha="right", va="top", fontsize=8.5, color=INK2)
    if not show_cfd_flow:
        yd = yb + 4.0
        for xx in (geo.taper_start, xe):
            ax.plot([xx, xx], [yb + 0.6, yd + 1.0], color=INK, lw=0.5)
        ax.add_patch(FancyArrowPatch((geo.taper_start, yd), (xe, yd), arrowstyle="<|-|>", mutation_scale=9, color=INK, lw=0.6, shrinkA=0, shrinkB=0))
        ax.text((geo.taper_start + xe) / 2, yd - 0.7, f"taper {geo.taper_length:g} mm", ha="center", fontsize=8.5, color=INK)

    # detail A: the entry, magnified
    ax.add_patch(Circle((0.8, 0), 4.4, fill=False, ls=(0, (2, 1.5)), lw=0.7, edgecolor=INK2, zorder=9))
    ax.text(3.8, -4.6, "A", fontsize=8, color=INK2)
    scale, x0, x1, yh = 2.0, -1.5, 16.5, 3.9
    w, h = (x1 - x0) * scale, 2 * yh * scale
    bx, by = 151 - w, 25.2
    ins = ax.inset_axes([bx, by, w, h], transform=ax.transData)
    ins.set_xlim(x0, x1)
    ins.set_ylim(yh, -yh)
    ins.set_xticks([]); ins.set_yticks([])
    for s in ins.spines.values():
        s.set_edgecolor(INK); s.set_linewidth(0.8)
    ins.add_patch(Rectangle((x0, -yh - 1), x1 - x0, 2 * yh + 2, facecolor="white", edgecolor=HATCH, hatch="////", lw=0))
    ins.add_patch(Polygon(p, closed=True, facecolor=PASSAGE, edgecolor=INK, lw=1.1))
    ins.plot([x0, x1], [0, 0], color=INK, lw=0.4, ls=(0, (12, 2, 2, 2)))
    name = {"step": "sudden step", "smooth": "smooth blend", "transition": "round to square, same area"}[geo.entry]
    ax.text(bx, by - 1.0, f"Detail A, entry: {name}", fontsize=8.5, color=INK2)
    return to_svg(fig, salt)
