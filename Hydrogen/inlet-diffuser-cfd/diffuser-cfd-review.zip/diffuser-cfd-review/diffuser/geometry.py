"""Straight-walled diffuser behind a round bore. Lengths in mm, x = 0 at the start of the bore."""

from __future__ import annotations

import math
from dataclasses import dataclass, fields, replace

import numpy as np

from .gasdynamics import borda_carnot


@dataclass(frozen=True)
class Diffuser:
    bore_diameter: float
    entry: str                 # "step", "smooth" or "transition" (constant-area round to square)
    entry_length: float        # bore length for a step, blend length otherwise
    start_width: float         # width at the start of the taper (wide plane)
    start_height: float        # height at the start of the taper (thin plane)
    taper_length: float
    exit_width: float
    exit_height: float
    exit_section_length: float
    vanes: int = 0
    vane_start: float = 15.0
    vane_end: float = 62.0
    vane_thickness: float = 0.5
    plates: int = 0
    plate_thickness: float = 0.4
    plates_start: float = 0.0  # measured from the end of the taper
    plates_end: float = 0.0

    @classmethod
    def from_dict(cls, base: dict, changes: dict | None = None) -> "Diffuser":
        names = {f.name for f in fields(cls)}
        merged = {k: v for k, v in {**base, **(changes or {})}.items() if k in names}
        return cls(**merged)

    def with_changes(self, **changes) -> "Diffuser":
        return replace(self, **changes)

    # ---------------------------------------------------------------- stations
    @property
    def taper_start(self) -> float:
        return self.entry_length

    @property
    def taper_end(self) -> float:
        return self.entry_length + self.taper_length

    @property
    def total_length(self) -> float:
        return self.taper_end + self.exit_section_length

    # ---------------------------------------------------------------- areas (mm^2)
    @property
    def bore_area(self) -> float:
        return math.pi * self.bore_diameter**2 / 4.0

    @property
    def start_area(self) -> float:
        return self.start_width * self.start_height

    @property
    def exit_area(self) -> float:
        return self.exit_width * self.exit_height

    @property
    def area_ratio_bore(self) -> float:
        return self.exit_area / self.bore_area

    @property
    def area_ratio_start(self) -> float:
        return self.exit_area / self.start_area

    @property
    def step_loss_coefficient(self) -> float:
        """Borda-Carnot loss of the entry, as a share of the bore dynamic pressure."""
        return borda_carnot(self.bore_area, self.start_area) if self.entry == "step" else 0.0

    # ---------------------------------------------------------------- angles (degrees)
    @property
    def tan_half_angle(self) -> float:
        return (self.exit_width - self.start_width) / (2.0 * self.taper_length)

    @property
    def wall_angle_wide(self) -> float:
        """Included angle 2θ between the side walls of the wide plane."""
        return 2.0 * math.degrees(math.atan(self.tan_half_angle))

    @property
    def wall_angle_thin(self) -> float:
        return 2.0 * math.degrees(math.atan((self.exit_height - self.start_height) / (2.0 * self.taper_length)))

    @property
    def virtual_apex(self) -> float:
        """x where the two wide-plane walls would meet if extended upstream."""
        return self.taper_start - self.start_width / (2.0 * self.tan_half_angle)

    @property
    def ray_angles(self) -> list[float]:
        """Angles to the axis of the walls and vanes; the vanes sit on rays from the virtual apex
        that divide the width into equal channels."""
        n = self.vanes + 1
        return [math.degrees(math.atan((-1.0 + 2.0 * k / n) * self.tan_half_angle)) for k in range(n + 1)]

    @property
    def vane_angles(self) -> list[float]:
        return self.ray_angles[1:-1]

    @property
    def channel_angles(self) -> list[float]:
        rays = self.ray_angles
        return [b - a for a, b in zip(rays[:-1], rays[1:])]

    @property
    def widest_channel_angle(self) -> float:
        return max(self.channel_angles)

    @property
    def equivalent_cone_angle(self) -> float:
        """Included angle of a cone with the same start and exit areas and length."""
        r1, r2 = math.sqrt(self.start_area / math.pi), math.sqrt(self.exit_area / math.pi)
        return 2.0 * math.degrees(math.atan((r2 - r1) / self.taper_length))

    @property
    def length_to_width(self) -> float:
        return self.taper_length / self.start_width

    # ---------------------------------------------------------------- outline for drawings
    def half_width(self, x: np.ndarray) -> np.ndarray:
        """Half-width of the passage in the wide plane at x."""
        x = np.asarray(x, dtype=float)
        xs, xe = self.taper_start, self.taper_end
        t = np.clip(x / xs, 0.0, 1.0)
        blend = t * t * (3.0 - 2.0 * t)
        if self.entry == "step":
            entry = np.where(x < xs, self.bore_diameter, self.start_width)
        else:
            entry = self.bore_diameter + (self.start_width - self.bore_diameter) * blend
        taper = self.start_width + (self.exit_width - self.start_width) * (x - xs) / self.taper_length
        width = np.where(x <= xs, entry, np.where(x <= xe, taper, self.exit_width))
        return width / 2.0

    def outline(self, n: int = 400) -> tuple[np.ndarray, np.ndarray]:
        """x and half-width along the upper wall, with the step drawn as a vertical edge."""
        x = np.linspace(0.0, self.total_length, n)
        x = np.unique(np.concatenate([x, [self.taper_start, self.taper_end]]))
        y = self.half_width(x)
        if self.entry == "step":
            i = int(np.searchsorted(x, self.taper_start))
            x = np.insert(x, i, self.taper_start)
            y = np.insert(y, i, self.bore_diameter / 2.0)
        return x, y

    def vane_lines(self) -> list[tuple[tuple[float, float], tuple[float, float]]]:
        apex = self.virtual_apex
        lines = []
        for angle in self.vane_angles:
            slope = math.tan(math.radians(angle))
            lines.append(((self.vane_start, (self.vane_start - apex) * slope),
                          (self.vane_end, (self.vane_end - apex) * slope)))
        return lines
