"""Quasi-one-dimensional compressible flow for a calorically perfect gas (SI units)."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable

GAMMA = 1.4      # ratio of specific heats for air
R_AIR = 287.0    # gas constant for air, J/(kg K)


def static_to_total_pressure(mach: float, gamma: float = GAMMA) -> float:
    """p / p0 for isentropic flow."""
    return (1.0 + 0.5 * (gamma - 1.0) * mach**2) ** (-gamma / (gamma - 1.0))


def static_to_total_temperature(mach: float, gamma: float = GAMMA) -> float:
    """T / T0."""
    return 1.0 / (1.0 + 0.5 * (gamma - 1.0) * mach**2)


def area_ratio(mach: float, gamma: float = GAMMA) -> float:
    """A / A* for isentropic flow at the given Mach number."""
    k = (gamma + 1.0) / (2.0 * (gamma - 1.0))
    return (1.0 / mach) * ((2.0 / (gamma + 1.0)) * (1.0 + 0.5 * (gamma - 1.0) * mach**2)) ** k


def mass_flow_function(mach: float, gamma: float = GAMMA, gas_constant: float = R_AIR) -> float:
    """m_dot * sqrt(T0) / (A * p0) at the given Mach number."""
    k = -(gamma + 1.0) / (2.0 * (gamma - 1.0))
    return math.sqrt(gamma / gas_constant) * mach * (1.0 + 0.5 * (gamma - 1.0) * mach**2) ** k


def choked_mass_flow(area: float, p0: float, t0: float, gamma: float = GAMMA, gas_constant: float = R_AIR) -> float:
    """Largest mass flow through an area for the given total conditions (Mach 1)."""
    return area * p0 / math.sqrt(t0) * mass_flow_function(1.0, gamma, gas_constant)


def sutherland_viscosity(temperature: float) -> float:
    """Dynamic viscosity of air, Pa s (Sutherland's law)."""
    t_ref, mu_ref, s = 273.15, 1.716e-5, 110.4
    return mu_ref * (temperature / t_ref) ** 1.5 * (t_ref + s) / (temperature + s)


def borda_carnot(area_small: float, area_large: float) -> float:
    """Loss coefficient of a sudden expansion, as a share of the upstream dynamic pressure."""
    return (1.0 - area_small / area_large) ** 2


def bisect(f: Callable[[float], float], lo: float, hi: float, tol: float = 1e-12, max_iter: int = 200) -> float:
    """Root of f between lo and hi; f(lo) and f(hi) must have opposite signs."""
    f_lo = f(lo)
    if f_lo * f(hi) > 0:
        raise ValueError("bisect: the root is not bracketed")
    for _ in range(max_iter):
        mid = 0.5 * (lo + hi)
        f_mid = f(mid)
        if (f_mid > 0) == (f_lo > 0):
            lo, f_lo = mid, f_mid
        else:
            hi = mid
        if hi - lo < tol:
            break
    return 0.5 * (lo + hi)


@dataclass(frozen=True)
class FlowState:
    """Uniform flow state at one cross-section."""

    mach: float
    total_pressure: float
    static_pressure: float
    temperature: float
    density: float
    velocity: float

    @property
    def dynamic_pressure(self) -> float:
        """Compressible dynamic pressure, p0 - p."""
        return self.total_pressure - self.static_pressure


def state_from_total_pressure(mach: float, p0: float, t0: float, gamma: float = GAMMA, gas_constant: float = R_AIR) -> FlowState:
    """Flow state from the Mach number and total conditions."""
    p = p0 * static_to_total_pressure(mach, gamma)
    t = t0 * static_to_total_temperature(mach, gamma)
    rho = p / (gas_constant * t)
    return FlowState(mach, p0, p, t, rho, mach * math.sqrt(gamma * gas_constant * t))


def uniform_state_from_static_pressure(mass_flow: float, area: float, p: float, t0: float,
                                       gamma: float = GAMMA, gas_constant: float = R_AIR) -> FlowState:
    """Uniform flow state for a known mass flow, area and static pressure (subsonic)."""
    target = mass_flow * math.sqrt(gas_constant * t0 / gamma) / (p * area)
    shape = lambda m: m * math.sqrt(1.0 + 0.5 * (gamma - 1.0) * m**2)  # noqa: E731
    if target >= shape(1.0):
        raise ValueError("the section would choke at this mass flow")
    mach = bisect(lambda m: shape(m) - target, 0.0, 1.0)
    p0 = p / static_to_total_pressure(mach, gamma)
    return state_from_total_pressure(mach, p0, t0, gamma, gas_constant)


def bore_state_for_recovery(mass_flow: float, bore_area: float, t0: float, exit_pressure: float, cp: float,
                            gamma: float = GAMMA, gas_constant: float = R_AIR) -> FlowState:
    """Bore flow state that delivers the mass flow when the diffuser recovers Cp.

    Cp = (p_exit - p1) / (p01 - p1). Together with the bore mass-flow equation this fixes the
    bore Mach number and the total pressure the supply must provide.
    """
    if not 0.0 <= cp < 1.0:
        raise ValueError("Cp must be at least 0 and below 1")

    def required(m: float) -> float:
        pr = static_to_total_pressure(m, gamma)
        return mass_flow_function(m, gamma, gas_constant) / (pr + cp * (1.0 - pr))

    target = mass_flow * math.sqrt(t0) / (bore_area * exit_pressure)
    if target >= required(1.0):
        raise ValueError("the bore would choke at this mass flow and Cp")
    mach = bisect(lambda m: required(m) - target, 1e-9, 1.0)
    pr = static_to_total_pressure(mach, gamma)
    p0 = exit_pressure / (pr + cp * (1.0 - pr))
    return state_from_total_pressure(mach, p0, t0, gamma, gas_constant)
