"""Checks against textbook values and against the hand calculations in the design review."""

import math
from pathlib import Path

import pytest

from diffuser import gasdynamics as gd
from diffuser.geometry import Diffuser
from diffuser.review import analyse_baseline, analyse_options, load_json

DATA = Path(__file__).resolve().parents[1] / "data"


@pytest.fixture(scope="module")
def inputs():
    fluent = load_json(DATA / "fluent_baseline.json")
    options = load_json(DATA / "options.json")
    geo = Diffuser.from_dict(options["baseline_geometry"])
    return fluent, options, geo


@pytest.fixture(scope="module")
def baseline(inputs):
    fluent, _, geo = inputs
    return analyse_baseline(fluent, geo)


# ---------------------------------------------------------------- textbook values (γ = 1.4)
def test_isentropic_relations_match_tables():
    assert gd.static_to_total_pressure(1.0) == pytest.approx(0.52828, abs=1e-5)
    assert gd.static_to_total_temperature(1.0) == pytest.approx(0.83333, abs=1e-5)
    assert gd.area_ratio(2.0) == pytest.approx(1.6875, abs=1e-4)
    assert gd.area_ratio(1.0) == pytest.approx(1.0)


def test_choked_flow_constant_for_air():
    # m_dot = 0.0404 A p0 / sqrt(T0) for air at Mach 1
    assert gd.mass_flow_function(1.0) == pytest.approx(0.0404, abs=1e-4)


def test_sudden_expansion_loss():
    assert gd.borda_carnot(1.0, 2.0) == pytest.approx(0.25)
    assert gd.borda_carnot(1.0, 1.0) == 0.0


def test_bisect_needs_a_bracketed_root():
    assert gd.bisect(lambda x: x * x - 2.0, 0.0, 2.0) == pytest.approx(math.sqrt(2.0))
    with pytest.raises(ValueError):
        gd.bisect(lambda x: x * x + 1.0, 0.0, 2.0)


# ---------------------------------------------------------------- geometry
def test_wall_angles_and_area_ratios(inputs):
    _, _, geo = inputs
    assert geo.wall_angle_wide == pytest.approx(16.5, abs=0.05)
    assert geo.wall_angle_thin == pytest.approx(2.0, abs=0.05)
    assert geo.area_ratio_bore == pytest.approx(8.98, abs=0.01)
    assert geo.area_ratio_start == pytest.approx(5.18, abs=0.01)
    assert geo.virtual_apex == pytest.approx(-23.2, abs=0.1)


def test_two_vanes_split_the_angle_into_equal_channels(inputs):
    _, _, geo = inputs
    vaned = geo.with_changes(vanes=2)
    assert [round(a, 2) for a in vaned.vane_angles] == [-2.77, 2.77]
    assert sum(vaned.channel_angles) == pytest.approx(geo.wall_angle_wide)
    assert vaned.widest_channel_angle == pytest.approx(5.5, abs=0.05)


def test_smooth_entry_has_no_step_loss(inputs):
    _, _, geo = inputs
    assert geo.step_loss_coefficient == pytest.approx(0.18, abs=0.005)
    assert geo.with_changes(entry="smooth").step_loss_coefficient == 0.0


# ---------------------------------------------------------------- baseline CFD
def test_baseline_matches_the_design_review(baseline):
    assert baseline.cp == pytest.approx(0.28, abs=0.005)
    assert baseline.loss_coefficient == pytest.approx(0.68, abs=0.005)
    assert baseline.cp_ideal == pytest.approx(0.99, abs=0.005)
    assert baseline.exit_uniform_velocity == pytest.approx(24.8, abs=0.1)
    assert baseline.exit_skew == pytest.approx(0.41, abs=0.01)
    assert baseline.bore_reynolds == pytest.approx(9.2e4, rel=0.02)
    assert baseline.choke_share == pytest.approx(0.89, abs=0.01)


def test_mass_flow_is_consistent(baseline):
    assert abs(baseline.mass_balance) < 0.002          # Fluent in vs out
    assert abs(baseline.mass_flow_check) < 0.01        # rho V A from the bore state vs the set value


def test_1d_model_reproduces_the_cfd_supply_pressure(baseline):
    assert baseline.model_supply_gauge == pytest.approx(baseline.supply_gauge, rel=0.02)


def test_better_recovery_needs_less_supply_pressure(inputs, baseline):
    fluent, options, _ = inputs
    df, _ = analyse_options(options, fluent, baseline)
    estimated = df.dropna(subset=["cp"]).drop(index="today")
    assert (estimated["supply_kPa"] < df.loc["today", "supply_kPa"]).all()
    assert (estimated["supply_low_kPa"] <= estimated["supply_kPa"]).all()
    assert (estimated["supply_kPa"] <= estimated["supply_high_kPa"]).all()
    assert df.loc["vanes", "supply_kPa"] == pytest.approx(20, abs=0.5)    # review: about +20 kPa
    assert df.loc["all", "supply_kPa"] == pytest.approx(16, abs=0.5)      # review: about +16 kPa


def test_choked_bore_is_reported():
    with pytest.raises(ValueError):
        gd.bore_state_for_recovery(0.02, math.pi * 0.003**2, 300.0, 101325.0, 0.3)
