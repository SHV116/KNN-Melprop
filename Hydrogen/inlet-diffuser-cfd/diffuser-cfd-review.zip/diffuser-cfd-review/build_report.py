"""Build the diffuser CFD review: compute every result from the raw Fluent values and write index.html.

    python build_report.py              # writes index.html and the results/ folder
    python build_report.py --out report.html
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from diffuser.figures import geometry_drawing, options_chart
from diffuser.geometry import Diffuser
from diffuser.report import angle_text, build_html
from diffuser.review import analyse_baseline, analyse_options, load_json

ROOT = Path(__file__).parent


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--out", type=Path, default=ROOT / "index.html", help="HTML file to write")
    args = parser.parse_args()

    fluent = load_json(ROOT / "data" / "fluent_baseline.json")
    options_data = load_json(ROOT / "data" / "options.json")
    checks = load_json(ROOT / "data" / "checks.json")

    today = Diffuser.from_dict(options_data["baseline_geometry"])
    baseline = analyse_baseline(fluent, today)
    options, geometries = analyse_options(options_data, fluent, baseline)

    figures = {"options": options_chart(options)}
    for key, geo in geometries.items():
        figures["geo_" + key] = geometry_drawing(geo, today, angle_text(geo), salt=key, show_cfd_flow=(key == "today"))

    html = build_html(fluent, today, baseline, options, geometries, checks, figures, ROOT / "images")
    args.out.write_text(html, encoding="utf-8")

    results = ROOT / "results"
    results.mkdir(exist_ok=True)
    (results / "baseline_metrics.json").write_text(json.dumps(baseline.as_dict(), indent=2), encoding="utf-8")
    options.drop(columns=["what_changes", "result", "catch"]).round(3).to_csv(results / "options_summary.csv")

    print(f"Cp {baseline.cp:.3f} (ideal {baseline.cp_ideal:.3f}), loss K {baseline.loss_coefficient:.3f}, "
          f"supply {baseline.supply_gauge / 1000:.1f} kPa, 1D model {baseline.model_supply_gauge / 1000:.1f} kPa")
    print(f"Wrote {args.out.name} ({args.out.stat().st_size // 1024} KB) and results/")


if __name__ == "__main__":
    main()
