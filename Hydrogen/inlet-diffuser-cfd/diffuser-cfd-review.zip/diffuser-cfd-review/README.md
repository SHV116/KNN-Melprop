# Inlet diffuser CFD review in Python

A Python tool that turns the raw results of my Ansys Fluent simulation into a full design review. It computes every number from the raw values, draws the figures with Matplotlib and writes a single-file HTML report.

I did the CFD as a member of the CFD team in the Hydrogen Section of MELprop, a student research group at Warsaw University of Technology. The part is the inlet diffuser of an engine test stand.

**See the report:** use the live version linked in this repository's About section, or open `index.html` in any browser. It is one file with no JavaScript, and it works offline.

## The finding

At idle (40,000 rpm, 7.42 g/s per inlet), the walls of the diffuser open at 16.5° behind a sudden Ø6 → 7 × 7 mm entry step. That is about twice the usual 8–10° limit for a straight diffuser of this length. In Fluent, the jet attaches to one wall and the other half of the taper flows backwards. The pressure recovery is Cp = 0.28, where a good straight diffuser reaches 0.6–0.7, and 68 % of the bore's dynamic pressure is lost.

## What the code does

1. **Reads the raw inputs:** the area-weighted Fluent values (`data/fluent_baseline.json`) and the geometry of each design option (`data/options.json`).
2. **Computes the baseline results** with compressible-flow relations:
   - the bore static and dynamic pressure, from total pressure and Mach number
   - Cp, the loss coefficient and the effectiveness
   - the Borda–Carnot loss of the entry step
   - the Reynolds number, with Sutherland viscosity
   - how close the bore is to choking
   - how skewed the exit flow is
3. **Computes the geometry of each option:** wall angles, area ratios, the virtual apex, splitter-vane angles and the equivalent cone angle.
4. **Works out the supply pressure each design option needs.** For each estimated Cp, it solves the compressible bore flow together with the recovery equation.
5. **Draws the figures with Matplotlib:** a comparison chart of the options and a to-scale drawing of each change against today's part.
6. **Writes the report:** `index.html`, plus `results/baseline_metrics.json` and `results/options_summary.csv`.

## Checks

`pytest` runs 12 tests:

- **Textbook values:** isentropic tables (p/p₀ = 0.5283 at Mach 1, A/A* = 1.6875 at Mach 2) and the choked-flow constant 0.0404 for air.
- **Geometry against my CAD measurements:** 2θ = 16.5° and 2.0°, area ratio 8.98, virtual apex at −23.2 mm, vanes at ±2.77°.
- **Baseline against the hand calculations in my review:** Cp 0.28, K 0.68, exit skew +41 %, 89–90 % of the choking flow.
- **The 1D model against Fluent:** at Fluent's Cp, the model gives the supply pressure Fluent needed within 2 % (23.7 vs 24.0 kPa).

Writing the code also caught a slip in my hand calculation. I had rounded 1 + 0.2M² to 1.0925 instead of 1.0930 for M = 0.682, which put the bore static pressure 0.15 kPa too high. Cp still rounds to 0.28.

## Run it

```
pip install -r requirements.txt
python build_report.py      # writes index.html and results/
pytest                      # runs the checks
```

## Layout

```
build_report.py           command-line entry point
diffuser/gasdynamics.py   isentropic relations, choking, Borda–Carnot, bore solve
diffuser/geometry.py      diffuser geometry: angles, areas, vanes, outline
diffuser/review.py        baseline results and the design-option table (pandas)
diffuser/figures.py       Matplotlib figures as inline SVG
diffuser/report.py        assembles index.html from template.html and report.css
data/                     raw Fluent values, geometry, options, validation checks
images/                   Fluent result images
tests/                    pytest checks
```

## Limits

- **Cp for the fixes is not simulated.** Only today's numbers come from CFD. The Cp values for the fixes are estimates from straight-diffuser data (Reneau et al. 1967) and still have to be confirmed with CFD.
- **The baseline still has open checks:** a mesh study, a y+ check and a transient run.
- **Software:** Ansys Fluent 2026 R1, teaching licence.

## How it was made

I ran the CFD and wrote the design review behind this repository. The Python was written with Claude as an AI coding assistant: I set out what to compute and show, and checked the results against my own hand calculations and Fluent results.

Geometry and results: MELprop student research group, Warsaw University of Technology, shared with the team's permission.

Harshith Varma Salibilla, [LinkedIn](https://www.linkedin.com/in/harshith-salibilla)
